import streamlit as st
import requests

# Set page styling
st.set_page_config(page_title="House Price Predictor", page_icon="🏡", layout="centered")

st.title("🏡 Smart House Price Predictor")
st.write("Provide the structural details of the house below to estimate its market valuation.")
st.write("---")

# Layout form inputs efficiently in columns
col1, col2 = st.columns(2)

with col1:
    area = st.number_input("Total Living Area (sq ft)", min_value=100, max_value=20000, value=1500, step=50)
    bedrooms = st.number_input("Number of Bedrooms", min_value=1, max_value=10, value=3, step=1)
    bathrooms = st.number_input("Number of Bathrooms", min_value=1, max_value=10, value=2, step=1)
    floors = st.number_input("Number of Floors", min_value=1, max_value=5, value=1, step=1)

with col2:
    year_built = st.number_input("Year Built", min_value=1800, max_value=2026, value=2000, step=1)
    location = st.selectbox("Property Location", ["Downtown", "Suburban", "Rural"])
    condition = st.selectbox("Overall Property Condition", ["Excellent", "Good", "Fair", "Poor"])
    garage = st.selectbox("Includes a Garage?", ["Yes", "No"])

st.write("---")

# Predict button
if st.button("Calculate Estimated Value", type="primary", use_container_width=True):
    # Form input dictionary mapping exactly to dataset columns
    payload = {
        "Area": area,
        "Bedrooms": bedrooms,
        "Bathrooms": bathrooms,
        "Floors": floors,
        "YearBuilt": year_built,
        "Location": location,
        "Condition": condition,
        "Garage": garage
    }
    
    # Send request to Backend API
    try:
        response = requests.post("http://127.0.0.1:5000/predict", json=payload)
        
        if response.status_code == 200:
            result = response.json()
            predicted_price = result['price']
            st.balloons()
            st.success(f"### 💰 Estimated Market Value: ${predicted_price:,.2f}")
        else:
            st.error(f"Backend Error: {response.json().get('error', 'Unknown Error')}")
            
    except requests.exceptions.ConnectionError:
        st.error("Could not connect to the backend server. Make sure app.py is running on port 5000!")